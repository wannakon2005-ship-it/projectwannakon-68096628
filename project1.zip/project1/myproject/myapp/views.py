from django.db import connection
import json
import random
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import user_passes_test
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Customers, Orders
CustomerProfile = Customers
Order = Orders
from django.utils import timezone

TRANSLATION_MAP = {
    'tshirt': 'เสื้อยืด',
    'white_shirt': 'เสื้อเชิ้ต',
    'coat': 'เสื้อโค้ท',
    'shorts': 'กางเกงขาสั้น',
    'jeans': 'กางเกงขายาว',
    'suit': 'ชุดสูท',
    'dress': 'ชุดเดรส',
    'curtain': 'ผ้าม่าน',
    'socks': 'ถุงเท้า',
}

def summarize_order_items(items_json):
    try:
        raw_items = json.loads(items_json)
    except Exception:
        return ''

    parts = []
    for key, item in (raw_items.items() if isinstance(raw_items, dict) else []):
        if not isinstance(item, dict):
            continue
        name = item.get('name', TRANSLATION_MAP.get(key, 'รายการทั่วไป'))
        try:
            total_qty = int(item.get('qty', item.get('wash_qty', 0) + item.get('iron_qty', 0)))
        except (TypeError, ValueError):
            total_qty = 0
        try:
            wash_qty = int(item.get('wash_qty', total_qty))
        except (TypeError, ValueError):
            wash_qty = 0
        try:
            iron_qty = int(item.get('iron_qty', 0))
        except (TypeError, ValueError):
            iron_qty = 0

        if wash_qty + iron_qty != total_qty:
            iron_qty = max(0, total_qty - wash_qty)

        details = []
        if wash_qty > 0:
            details.append(f'ซัก {wash_qty}')
        if iron_qty > 0:
            details.append(f'ซักรีด {iron_qty}')
        detail_text = ' / '.join(details) if details else 'ไม่มีรายการ'
        parts.append(f'{name} ({detail_text})')

    return ', '.join(parts)

# --- ส่วนตรวจสอบสิทธิ์ Admin ---
def is_admin(user):
    return user.is_staff

# 0. หน้า Landing page
def index_view(request):
    return render(request, 'index.html')

# 1. หน้า เข้าสู่ระบบ
def login_view(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        pwd = request.POST.get('password')
        user = authenticate(request, username=uname, password=pwd)

        if user is not None:
            login(request, user)
            if user.is_staff:
                return redirect('/admin-dashboard/')
            else:
                return redirect('/servicesusers/')
        else:
            messages.error(request, 'ชื่อผู้ใช้ หรือ รหัสผ่าน ไม่ถูกต้อง!')
    return render(request, 'login.html')

# 1.5. หน้า Logout
def logout_view(request):
    logout(request)
    return redirect('index')

# 2. หน้า สมัครสมาชิก
def register_view(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        pwd = request.POST.get('password')
        cpwd = request.POST.get('confirm_password')

        if pwd != cpwd:
            messages.error(request, 'รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน!')
            return render(request, 'register.html')
            
        if len(pwd) < 6:
            messages.error(request, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร!')
            return render(request, 'register.html')

        if User.objects.filter(username=uname).exists():
            messages.error(request, 'ชื่อผู้ใช้นี้ถูกใช้งานแล้ว!')
            return render(request, 'register.html')

        try:
            user = User.objects.create_user(username=uname, password=pwd)
            user.save()
            # สร้าง Profile สำหรับเก็บแต้มทันทีที่สมัคร
            CustomerProfile.objects.create(user=user)
            messages.success(request, 'สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ')
            return redirect('/') 
        except Exception as e:
            messages.error(request, f'เกิดข้อผิดพลาด: {str(e)}')
    return render(request, 'register.html')

# 3. หน้า เลือกบริการซักผ้า (ลูกค้าสั่งออเดอร์)
def users_view(request):
    from .models import Customers # หรือชื่อ Model ที่เก็บข้อมูลลูกค้า
    customers = Customers.objects.all()
    
    context = {
        'customers': customers,
    }
    
    return render(request, 'admin_dashboard.html', context)

    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        pickup_date = request.POST.get('pickup_date')
        times = request.POST.get('times')
        cart_data_str = request.POST.get('cart_data')
        used_points = int(request.POST.get('used_points', 0)) # รับแต้มที่ลูกค้าสั่งใช้ลดราคา
        
        payment_method_raw = request.POST.get('payment_method')
        payment_th = "เงินสด (ชำระหน้าร้าน)" if payment_method_raw == 'cash' else "โอนเงิน / สแกน QR"

        try:
            cart_data = json.loads(cart_data_str)
        except:
            cart_data = {}

        total_price = 0
        items_list = []
        cart_data_with_names = {}
        
        for key, item in cart_data.items():
            try:
                total_qty = int(item.get('qty', 0))
                wash_qty = int(item.get('wash_qty', total_qty))
                iron_qty = int(item.get('iron_qty', 0))
                wash_price = int(item.get('wash_price', item.get('price', 0)))
                iron_price = int(item.get('iron_price', wash_price))
            except (ValueError, TypeError):
                total_qty = wash_qty = iron_qty = wash_price = iron_price = 0

            if wash_qty + iron_qty != total_qty:
                iron_qty = max(0, total_qty - wash_qty)

            item_name = TRANSLATION_MAP.get(key, item.get('name', key))
            item_total = wash_qty * wash_price + iron_qty * iron_price

            if total_qty > 0:
                total_price += item_total
                items_list.append({
                    'name': item_name,
                    'total_qty': total_qty,
                    'wash_qty': wash_qty,
                    'iron_qty': iron_qty,
                    'wash_price': wash_price,
                    'iron_price': iron_price,
                    'item_total': item_total,
                })
                cart_data_with_names[key] = {
                    'qty': total_qty,
                    'wash_qty': wash_qty,
                    'iron_qty': iron_qty,
                    'wash_price': wash_price,
                    'iron_price': iron_price,
                    'name': item_name,
                }

        # --- Logic หักพ้อยท์ส่วนลด ---
        if request.user.is_authenticated and used_points > 0:
            profile, _ = CustomerProfile.objects.get_or_create(user=request.user)
            used_points = min(used_points, profile.points)
            discount = used_points // 100 # 100 พ้อยท์ = 1 บาท
            used_points = discount * 100
            profile.points = max(profile.points - used_points, 0)
            profile.save()
        else:
            discount = used_points // 100 # 100 พ้อยท์ = 1 บาท

        final_total = total_price - discount
        if final_total < 0: final_total = 0

        # บันทึกลง Database
        order_id = f"ORD-{random.randint(10000, 99999)}"
        new_order = Order.objects.create(
            order_id=order_id,
            customer=request.user if request.user.is_authenticated else None,
            customer_name=name,
            phone=phone,
            items_json=json.dumps(cart_data_with_names),
            original_total=total_price,
            total_price=final_total,
            pickup_date=pickup_date,
            times=times,
            status='received'
        )

        context = {
            'order': new_order,
            'payment_method': payment_th,
            'items_list': items_list,
            'discount': discount
        }
        return render(request, 'confirm.html', context)
    
    response = render(request, 'servicesusers.html', {'user_points': user_points})
    response['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'
    return response

# 4. API สร้างออเดอร์แบบ AJAX เพื่อให้หน้าเว็บไม่รีเฟรช
def submit_order_ajax(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'})

    name = data.get('name')
    phone = data.get('phone')
    pickup_date = data.get('pickup_date')
    times = data.get('times')
    cart_data = data.get('cart_data', {})
    used_points = int(data.get('used_points', 0))
    payment_method_raw = data.get('payment_method')
    payment_th = "เงินสด (ชำระหน้าร้าน)" if payment_method_raw == 'cash' else "โอนเงิน / สแกน QR"

    total_price = 0
    items_list = []
    cart_data_with_names = {}
    for key, item in cart_data.items():
        try:
            total_qty = int(item.get('qty', 0))
            wash_qty = int(item.get('wash_qty', total_qty))
            iron_qty = int(item.get('iron_qty', 0))
            wash_price = int(item.get('wash_price', item.get('price', 0)))
            iron_price = int(item.get('iron_price', wash_price))
        except (ValueError, TypeError):
            total_qty = wash_qty = iron_qty = wash_price = iron_price = 0

        if wash_qty + iron_qty != total_qty:
            iron_qty = max(0, total_qty - wash_qty)

        item_name = TRANSLATION_MAP.get(key, item.get('name', key))
        item_total = wash_qty * wash_price + iron_qty * iron_price
        if total_qty > 0:
            total_price += item_total
            items_list.append({
                'name': item_name,
                'total_qty': total_qty,
                'wash_qty': wash_qty,
                'iron_qty': iron_qty,
                'wash_price': wash_price,
                'iron_price': iron_price,
                'item_total': item_total,
            })
            cart_data_with_names[key] = {
                'qty': total_qty,
                'wash_qty': wash_qty,
                'iron_qty': iron_qty,
                'wash_price': wash_price,
                'iron_price': iron_price,
                'name': item_name,
            }

    remaining_points = 0
    if request.user.is_authenticated and used_points > 0:
        profile, _ = CustomerProfile.objects.get_or_create(user=request.user)
        used_points = min(used_points, profile.points)
        money_discount = used_points // 100
        used_points = money_discount * 100
        profile.points = max(profile.points - used_points, 0)
        profile.save()
        remaining_points = profile.points
    elif request.user.is_authenticated:
        profile, _ = CustomerProfile.objects.get_or_create(user=request.user)
        remaining_points = profile.points
        money_discount = 0
    else:
        money_discount = 0

    final_total = total_price - money_discount
    if final_total < 0:
        final_total = 0

    order_id = f"ORD-{random.randint(10000, 99999)}"
    Order.objects.create(
        order_id=order_id,
        customer=request.user if request.user.is_authenticated else None,
        customer_name=name,
        phone=phone,
        items_json=json.dumps(cart_data_with_names),
        original_total=total_price,
        total_price=final_total,
        pickup_date=pickup_date,
        times=times,
        status='received'
    )

    return JsonResponse({
        'status': 'success',
        'order_id': order_id,
        'remaining_points': remaining_points,
    })

# 5. API ให้ข้อมูลคะแนนลูกค้าปัจจุบัน
def customer_points_api(request):
    all_customers = Customers.objects.all()
    items = []
    for c in all_customers:
        items.append({
            'id': c.cus_id,         
            'name': c.cus_name,     
            'points': c.total_points 
        })
    return JsonResponse({'status': 'success', 'customers': items})

def current_points_api(request):
    if request.user.is_authenticated:
        profile, _ = CustomerProfile.objects.get_or_create(user=request.user)
        return JsonResponse({'status': 'success', 'points': profile.points})
    return JsonResponse({'status': 'success', 'points': 0})

# 7. API ให้ข้อมูลออเดอร์ปัจจุบันสำหรับ real-time updates
def get_orders_api(request):
    from .models import Orders as Order 
    orders = Order.objects.all().order_by('-order_date')

    orders_data = []
    for order in orders:
        orders_data.append({
            'order_id': order.order_id,
            'customer_name': order.cus.cus_name if order.cus else '-',
            # ดึงเบอร์จากตาราง Customers ผ่านความสัมพันธ์ cus
            'phone': order.cus.telephone if order.cus else '-', 
            'pickup_date': order.order_date.strftime('%d/%m/%Y %H:%M') if order.order_date else '-',
            
            # แสดงสถานะตามที่พิมพ์ใน SQL เป๊ะๆ
            'status': order.order_status,          
            'status_display': order.order_status, 
            
            'total_price': f"{order.total_amount:,.2f}",
            'item_summary': 'ซักพับ/ซักรีด', 
        })
    return JsonResponse({'status': 'success', 'orders': orders_data})

# 6. หน้า Admin Dashboard
@user_passes_test(is_admin)
def admin_dashboard(request):
    orders_all = Order.objects.all()
    today = timezone.now().date()

    for order in orders_all:
        order.item_summary = summarize_order_items(order.items_json)
    
    total_orders = orders_all.exclude(status__in=['delivered', 'cancelled']).count()
    washing_count = orders_all.filter(status='washing').count()
    ready_count = orders_all.filter(status='ready').count()
    
    # รายได้วันนี้ (นับเฉพาะที่จ่ายเงินสำเร็จแล้ว)
    total_revenue = sum(o.total_price for o in orders_all.filter(status='delivered', created_at__date=today))

    # ยอดรวมรอรับ (ออเดอร์ค้างจ่าย)
    total_pending_revenue = sum(o.total_price for o in orders_all.exclude(status__in=['delivered', 'cancelled']))


    customers = User.objects.filter(is_staff=False).order_by('-date_joined')
    for customer in customers:
        CustomerProfile.objects.get_or_create(user=customer)

    context = {
        'orders': orders_all.order_by('-created_at'),
        'total_orders': total_orders,
        'total_revenue': total_revenue,
        'total_pending_revenue': total_pending_revenue,
        'washing_count': washing_count,
        'ready_count': ready_count,
        'customers': customers,
    }
    return render(request, 'admin_dashboard.html', context)

# 5. API อัปเดตสถานะ (พร้อมระบบเพิ่มแต้มเซเว่น!)
@csrf_exempt
def update_order_status(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            order_pk = data.get('id')
            new_status = data.get('status')
            
            order = Order.objects.get(id=order_pk)
            previous_status = order.status
            order.status = new_status
            order.save()

            response_data = {'status': 'success'}

            # --- 🟢 ระบบเพิ่มแต้มเมื่อจ่ายเงินสำเร็จ (delivered) 🟢 ---
            # ทุก 1 บาท ได้ 1 พ้อยท์
            if new_status == 'delivered' and previous_status != 'delivered':
                customer_user = order.customer
                # ใช้ customer FK ที่เก็บไว้จากตอนสั่งออเดอร์ เพื่อมั่นใจว่าเพิ่มพ้อยให้ถูกคน
                if customer_user:
                    profile, _ = CustomerProfile.objects.get_or_create(user=customer_user)
                    profile.points += int(order.original_total)
                    profile.save()
                    response_data['customer_id'] = customer_user.id
                    response_data['customer_points'] = profile.points

            return JsonResponse(response_data)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

# Cancel Order
@csrf_exempt
def cancel_order(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            order_pk = data.get('id')
            order = Order.objects.get(id=order_pk)
            
            if order.status == 'cancelled':
                return JsonResponse({'status': 'error', 'message': 'รายการนี้ถูกยกเลิกแล้ว'})
            
            if order.status == 'delivered':
                return JsonResponse({'status': 'error', 'message': 'ไม่สามารถยกเลิกรายการที่ส่งแล้ว'})         
            order.status = 'cancelled'
            order.save()
            return JsonResponse({'status': 'success', 'message': 'ยกเลิกรายการสำเร็จ'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@csrf_exempt
def clear_history(request):
    if request.method == 'POST':
        try:
            deleted, _ = Order.objects.filter(status='delivered').delete()
            return JsonResponse({'status': 'success', 'deleted_count': deleted})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

def confirm_view(request):
    order_id = request.GET.get('order_id')
    payment_method = request.GET.get('payment_method', 'เงินสด (ชำระหน้าร้าน)')
    if not order_id:
        return redirect('/servicesusers/')

    order = get_object_or_404(Order, order_id=order_id)
    try:
        raw_items = json.loads(order.items_json)
        items_list = []
        for key, item in raw_items.items():
            if not isinstance(item, dict):
                continue
            try:
                total_qty = int(item.get('qty', item.get('wash_qty', 0) + item.get('iron_qty', 0)))
                wash_qty = int(item.get('wash_qty', total_qty))
                iron_qty = int(item.get('iron_qty', 0))
                wash_price = int(item.get('wash_price', item.get('price', 0)))
                iron_price = int(item.get('iron_price', wash_price))
            except (ValueError, TypeError):
                total_qty = wash_qty = iron_qty = wash_price = iron_price = 0

            if wash_qty + iron_qty != total_qty:
                iron_qty = max(0, total_qty - wash_qty)

            item_total = wash_qty * wash_price + iron_qty * iron_price
            items_list.append({
                'name': item.get('name', TRANSLATION_MAP.get(key, 'รายการทั่วไป')),
                'total_qty': total_qty,
                'wash_qty': wash_qty,
                'iron_qty': iron_qty,
                'wash_price': wash_price,
                'iron_price': iron_price,
                'item_total': item_total,
            })
    except Exception:
        items_list = []

    context = {
        'order': order,
        'payment_method': payment_method,
        'items_list': items_list,
        'discount': 0,
    }
    return render(request, 'confirm.html', context)


from .models import VOrderstatus, VDailyrevenue

def admin_dashboard(request):
    from .models import Order 
    orders = Order.objects.all()
    
    print(f"DEBUG: เจอออเดอร์ทั้งหมด {orders.count()} รายการ")
    for o in orders:
        print(f"DEBUG: Order ID = {o.order_id}, Total = {o.total_amount}")
    # ------------------

    return render(request, 'admin_dashboard.html', {'orders': orders})

from django.db.models import Sum, Count

def get_dashboard_stats(request):
    from .models import Orders as Order
    from django.utils import timezone
    
    # 1. งานใหม่วันนี้
    new_orders = Order.objects.filter(order_date__date=timezone.now().date()).count()
    
    # 2. กำลังดำเนินการ (ต้องสะกดให้ตรงกับในตาราง SQL ของคุณเป๊ะๆ)
    # สมมติใน SQL ของคุณใช้คำว่า 'กำลังดำเนินการ'
    processing = Order.objects.filter(order_status='กำลังดำเนินการ').count()
    
    # 3. รอรับผ้าคืน (สมมติใน SQL ใช้คำว่า 'เสร็จแล้ว')
    ready_to_pickup = Order.objects.filter(order_status='เสร็จแล้ว').count()
    
    # 4. รายรับทั้งหมด
    total_revenue = Order.objects.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    return JsonResponse({
        'status': 'success',
        'new_orders': new_orders,
        'processing': processing,
        'ready_to_pickup': ready_to_pickup,
        'total_revenue': float(total_revenue)
    })

def get_order_history_api(request):
    from .models import Orders as Order
    from django.http import JsonResponse
    
    # ดึงเฉพาะรายการที่สถานะคือ 'ส่งมอบแล้ว'
    history_orders = Order.objects.filter(order_status='ส่งมอบแล้ว').order_by('-order_date')

    data = []
    for order in history_orders:
        data.append({
            'order_id': order.order_id,
            'cus_name': order.cus.cus_name if order.cus else '-',
            'order_date': order.order_date.strftime('%d/%m/%Y') if order.order_date else '-',
            'pickup_date': order.actual_pickup_date.strftime('%d/%m/%Y') if order.actual_pickup_date else '-',
            'total_price': f"{order.total_amount:,.2f}",
            'status': order.order_status,
        })
    return JsonResponse({'status': 'success', 'history': data})

def get_loyalty_data_api(request):
    from django.db import connection
    try:
        with connection.cursor() as cursor:
            # เช็กตรงนี้: ถ้าใน SQL ชื่อ Customer (ไม่มี s) ต้องเขียนแบบนี้เป๊ะๆ
            cursor.execute("SELECT Cus_name, Telephone, Total_Points FROM dbo.Customers")
            rows = cursor.fetchall()

        data = []
        for row in rows:
            data.append({
                'name': str(row[0]),
                'phone': str(row[1]) if row[1] else '-',
                'points': int(row[2]) if row[2] is not None else 0
            })
        return JsonResponse({'status': 'success', 'customers': data})

    except Exception as e:
        # บรรทัดนี้สำคัญ! ถ้ามันยัง 500 พี่ดูที่หน้าจอดำ (Terminal) เลย 
        # มันจะพิมพ์ว่า "SQL Error: ...." บอกเลยว่าสะกดอะไรผิด
        print(f"SQL Error: {e}") 
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)